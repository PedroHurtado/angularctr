import styles from "./day.css" assert { type: "css" };
export class Day extends HTMLElement{
    _day
    _shadow
    constructor(){
        super()
        this._shadow = this.attachShadow({mode:'open'})
        this._shadow.adoptedStyleSheets = [styles]        
    }
    set day(value){        
        if(value!=this.day){
            this._day = value
            this._shadow.textContent = this.day
        }
    }
    get day(){
        return this._day
    }
}
customElements.define('ctr-day',Day)