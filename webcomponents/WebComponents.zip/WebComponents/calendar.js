import styles from "./calendar.css" assert { type: "css" };
import {Day} from './day.js'

/*const styles = new CSSStyleSheet();
styles.replace(`:host{
    color: var(--color-calendar, red)
}`);*/

const template = document.getElementById('calendar')

function* getDays(){
      for(let i=0;i<31;i++){
        yield i+1;
      }
}
class Calendar extends HTMLElement{
    static observedAttributes = ["date"];
    _date=null
    constructor(){
        super();
        
        /*
            open: shadowRoot!==null
            closed : shadowRoot === null
        */
        const shadow = this.attachShadow({mode:'closed'})        
        shadow.adoptedStyleSheets = [styles]
        this._createDays(shadow);
        shadow.addEventListener('click',this._handlerClick)
        
    }
    _handlerClick(ev){
        ev.stopPropagation();
        const node = ev.composedPath().find(n=>n.dataset && 'day' in n.dataset)
        if(node){
            const {day} = node.dataset
            console.log(day)
        }
    }
    _createDays(shadow){
        for(let v of getDays()){
            //const day = document.createElement('ctr-day')
            const day = new Day();
            day.setAttribute('data-day', v)
            day.day = v;
            shadow.appendChild(day)
        }

    }

    /*connectedCallback(){
        console.log("connectd callback")
    }
    disconnectedCallback(){
        console.log("dis connectd callback")
    }
    set date(value){
        this._date = value
    }
    get date(){
        return this._date
    }
    attributeChangedCallback(name,olvalue,newvalue){
        this[name] = newvalue
    }*/
}

customElements.define("ctr-calendar",Calendar)

/* nombre de componente no valido
    "calendar"->extension del propio html
    "catastro_calendar"-> HTMLUnknownElement 
*/

/*
   prefix-calendar
*/

/**
 * CICLO DE VIDA
 *  constructor->funciona igual que angular
 *  connectedCallback->parentNode not null->ngOninit()
 *  disconnectdCallback->parentNode === null->ngOnDestroy
 *  attributeChangedCallback->ngOnchanges
 *      static observedAttributes = ["date"];
 */

/*
    1. no puedo pasar datos de forma declarativa a un setter

        @input nam:sytring   [name]="Pedro"

    2. no puedo pasar objetos
        serializar a json->desrializar de json
*/

/*
   slot->permite introducir html externo hacia el shadow

   <slot></slot>

   <slot name="toolbar"></slot>

   <div slot ="toolbar"></div>
*/