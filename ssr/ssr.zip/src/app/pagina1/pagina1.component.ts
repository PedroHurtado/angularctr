import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {HttpClient, HttpClientModule} from '@angular/common/http'
import { Customer } from '../customer';
import {lastValueFrom} from 'rxjs'

@Component({
  selector: 'app-pagina1',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './pagina1.component.html',
  styleUrls: ['./pagina1.component.css']
})
export class Pagina1Component {

  customer:Customer|null = null

  constructor(private readonly http:HttpClient){
    this.getData()
  }
  async getData(){
      this.customer = await lastValueFrom(this.http.get<Customer>("http://localhost:8080/customer.json"))
  }
  handlerClick(){
    console.log(this.customer)
  }
}
