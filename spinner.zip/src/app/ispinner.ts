import { SpinnerService } from "./spinner.service";

export interface ISpinner {
  get spinner() : SpinnerService
}
